/*Objet plateau

0 = mer
1 = ile
2 = bateau

//************************ */


function Plateau(size,nbrBoat,nbrIsle){

    this.size = size;
    this.nbrBoat = nbrBoat;
    this.nbrIsle = nbrIsle;

    this.board = [];

    //**************************************************************** */
    // GETTER   
    //**************************************************************** */
    
    // retourne la size du plateau
    this.getsize = function(){
        return this.size;
    }

    //renvoie le nombre de bateau
    this.getNbrBoat = function(){
        return this.nbrBoat;
    }

    //renvoie le nombre de bateau
    this.getBoard = function(){
        return this.board;
    }

    //**************************************************************** */
    // METHODE
    //**************************************************************** */

    //******************************** */
    //génère le plateau
    //******************************** */
    this.generateBoard = function(){
        
        //Création ligne à ligne
        for(let i = 0; i < this.size;i++){

            let line = [];

            //création des cases de chaque ligne
            for(let j = 0; j < this.size; j++){
                
                line.push('0');

            }

            this.board.push(line);

        }

        //Création des iles
        this.generateIsle();
    }

    //******************************** */
    //génère les iles
    //******************************** */
    this.generateIsle = function(){

        for(let i = 0;i < this.nbrIsle; i++){

            let randomNumber = Math.floor(Math.random() * 8);
            let randomNumber2 = Math.floor(Math.random() * 8);

            this.board[randomNumber][randomNumber2] = '1';
            this.board[randomNumber][randomNumber2+1] = '1';
            this.board[randomNumber+1][randomNumber2] = '1';
            this.board[randomNumber+1][randomNumber2+1] = '1';
        }

    }

    //******************************** */
    //génère des bateaux
    //******************************** */

    this.generateBoat = function(){

        for(let i = 0; i< this.nbrBoat;i++){

            let generate = false;

            while(!generate){
                let randomNumber = Math.floor(Math.random() * 8);
                let randomNumber2 = Math.floor(Math.random() * 8);
                
                if(this.board[randomNumber][randomNumber2] == '0'){

                    this.board[randomNumber][randomNumber2] = '2';
                    
                    if(this.board[randomNumber+1][randomNumber2] == '0'){
                        this.board[randomNumber+1][randomNumber2] = '2';
                    }

                    generate = true;
                }
            }
        




        }

    }

    //******************************** */
    //test présence bateaux
    //******************************** */

    this.testPresenceBoat = function(line,column){

        if(this.board[line][column] == '2'){
            return true;
        }

        return false;
    }
    
}