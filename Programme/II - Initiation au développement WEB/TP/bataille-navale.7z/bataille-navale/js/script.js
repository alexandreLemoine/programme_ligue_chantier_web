  //Génération du plateau
  var plateau = new Plateau(10,2,2);
  plateau.generateBoard();

document.addEventListener("DOMContentLoaded", function() {

    // Génération graphique du plateau
    gerateGraphicBoard();

    // Génération des bateaux
    plateau.generateBoat();

});

function testPresenceBoat(line,column){
        
    if(plateau.testPresenceBoat(line,column)){
        console.log('TOUCHE !');
        document.getElementById('column-'+line+'-'+column).style.backgroundColor ='grey';
    }
    else{
        console.log('CHOU BLANC');
    }

}

function gerateGraphicBoard(){

    let graphicLine = '';

    for(let line = 0; line < plateau.getBoard().length;line++){
        
        graphicLine += "<div class='line'>";

        for(let column = 0; column < plateau.getBoard().length;column++){
        
            let status = plateau.getBoard()[line][column];
            let graphicColumn = '';

            switch(status){

                case '0' :

                    graphicColumn += '<div Onclick="testPresenceBoat('+line+','+column+')" id="column-'+line+'-'+column+'" class="column ocean"></div>';
                    break;

                case '1' :

                    graphicColumn += '<div class="column isle"></div>';
                    break;

                    case '2' :

                    graphicColumn += '<div class="column boat"></div>';
                    break;
            }

            graphicLine += graphicColumn;
            }

            graphicLine += '</div>';

    }

    document.getElementById('boardGame').innerHTML = graphicLine;
}

